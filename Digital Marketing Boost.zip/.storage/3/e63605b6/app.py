import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import numpy as np
import requests
import json
from typing import Dict, List
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import re

# Page configuration
st.set_page_config(
    page_title="DPD Digital Marketing Hub",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #1f77b4;
    }
    .sidebar .sidebar-content {
        background-color: #f8f9fa;
    }
    .success-message {
        color: #28a745;
        font-weight: bold;
    }
    .warning-message {
        color: #ffc107;
        font-weight: bold;
    }
    .error-message {
        color: #dc3545;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

class DigitalMarketingHub:
    def __init__(self):
        self.initialize_session_state()
    
    def initialize_session_state(self):
        """Initialize session state variables"""
        if 'sales_data' not in st.session_state:
            st.session_state.sales_data = self.generate_sample_sales_data()
        if 'email_campaigns' not in st.session_state:
            st.session_state.email_campaigns = []
        if 'seo_keywords' not in st.session_state:
            st.session_state.seo_keywords = self.get_sample_seo_data()
        if 'social_media_posts' not in st.session_state:
            st.session_state.social_media_posts = []
    
    def generate_sample_sales_data(self):
        """Generate sample sales data for DPD journals and Employment News"""
        dates = pd.date_range(start='2024-01-01', end='2024-12-31', freq='D')
        
        data = []
        for date in dates:
            # DPD Journals
            dpd_sales = np.random.randint(50, 200)
            dpd_revenue = dpd_sales * np.random.uniform(15, 25)
            
            # Employment News
            emp_news_sales = np.random.randint(100, 500)
            emp_news_revenue = emp_news_sales * np.random.uniform(5, 12)
            
            data.append({
                'Date': date,
                'Product': 'DPD Journals',
                'Channel': np.random.choice(['Website', 'Amazon', 'Social Media', 'Email']),
                'Sales': dpd_sales,
                'Revenue': dpd_revenue,
                'Conversion_Rate': np.random.uniform(2, 8)
            })
            
            data.append({
                'Date': date,
                'Product': 'Employment News',
                'Channel': np.random.choice(['Website', 'Amazon', 'Social Media', 'Email']),
                'Sales': emp_news_sales,
                'Revenue': emp_news_revenue,
                'Conversion_Rate': np.random.uniform(3, 12)
            })
        
        return pd.DataFrame(data)
    
    def get_sample_seo_data(self):
        """Generate sample SEO keyword data"""
        return {
            'DPD Journals': {
                'keywords': ['government job preparation', 'civil services books', 'competitive exam guides'],
                'rankings': [3, 7, 12],
                'search_volume': [15000, 8500, 6200]
            },
            'Employment News': {
                'keywords': ['employment news paper', 'government job alerts', 'sarkari naukri news'],
                'rankings': [2, 5, 8],
                'search_volume': [25000, 18000, 12000]
            }
        }
    
    def render_dashboard_overview(self):
        """Render the main dashboard overview"""
        st.markdown('<h1 class="main-header">🚀 DPD Digital Marketing Hub</h1>', unsafe_allow_html=True)
        
        # Key Metrics
        col1, col2, col3, col4 = st.columns(4)
        
        total_sales = st.session_state.sales_data['Sales'].sum()
        total_revenue = st.session_state.sales_data['Revenue'].sum()
        avg_conversion = st.session_state.sales_data['Conversion_Rate'].mean()
        
        with col1:
            st.metric(
                label="📈 Total Sales",
                value=f"{total_sales:,}",
                delta=f"+{np.random.randint(5, 15)}% vs last month"
            )
        
        with col2:
            st.metric(
                label="💰 Total Revenue",
                value=f"₹{total_revenue:,.0f}",
                delta=f"+{np.random.randint(8, 20)}% vs last month"
            )
        
        with col3:
            st.metric(
                label="🎯 Avg Conversion Rate",
                value=f"{avg_conversion:.1f}%",
                delta=f"+{np.random.uniform(0.5, 2.0):.1f}% vs last month"
            )
        
        with col4:
            active_campaigns = len(st.session_state.email_campaigns)
            st.metric(
                label="📧 Active Campaigns",
                value=active_campaigns,
                delta=f"+{np.random.randint(1, 5)} new this week"
            )
        
        # Sales Trends
        st.subheader("📊 Sales Performance Trends")
        
        # Monthly aggregation
        monthly_data = st.session_state.sales_data.groupby([
            st.session_state.sales_data['Date'].dt.to_period('M'), 'Product'
        ]).agg({
            'Sales': 'sum',
            'Revenue': 'sum'
        }).reset_index()
        monthly_data['Date'] = monthly_data['Date'].astype(str)
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig_sales = px.line(
                monthly_data, 
                x='Date', 
                y='Sales', 
                color='Product',
                title='Monthly Sales Trend'
            )
            st.plotly_chart(fig_sales, use_container_width=True)
        
        with col2:
            fig_revenue = px.line(
                monthly_data, 
                x='Date', 
                y='Revenue', 
                color='Product',
                title='Monthly Revenue Trend'
            )
            st.plotly_chart(fig_revenue, use_container_width=True)
        
        # Channel Performance
        st.subheader("🌐 Channel Performance Analysis")
        
        channel_data = st.session_state.sales_data.groupby(['Channel', 'Product']).agg({
            'Sales': 'sum',
            'Revenue': 'sum',
            'Conversion_Rate': 'mean'
        }).reset_index()
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig_channel = px.bar(
                channel_data,
                x='Channel',
                y='Sales',
                color='Product',
                title='Sales by Channel',
                barmode='group'
            )
            st.plotly_chart(fig_channel, use_container_width=True)
        
        with col2:
            fig_conversion = px.scatter(
                channel_data,
                x='Sales',
                y='Conversion_Rate',
                color='Channel',
                size='Revenue',
                title='Sales vs Conversion Rate by Channel'
            )
            st.plotly_chart(fig_conversion, use_container_width=True)
    
    def render_email_marketing(self):
        """Render email marketing management interface"""
        st.header("📧 Email Marketing Campaign Manager")
        
        # Campaign Creation
        st.subheader("Create New Campaign")
        
        col1, col2 = st.columns(2)
        
        with col1:
            campaign_name = st.text_input("Campaign Name")
            subject_line = st.text_input("Subject Line")
            target_product = st.selectbox("Target Product", ["DPD Journals", "Employment News", "Both"])
        
        with col2:
            send_date = st.date_input("Send Date")
            target_segment = st.selectbox("Target Segment", ["All Subscribers", "Previous Buyers", "Inactive Users"])
            campaign_type = st.selectbox("Campaign Type", ["Promotional", "Educational", "Newsletter"])
        
        email_content = st.text_area("Email Content", height=200, placeholder="Enter your email content here...")
        
        if st.button("Create Campaign"):
            if campaign_name and subject_line and email_content:
                new_campaign = {
                    'name': campaign_name,
                    'subject': subject_line,
                    'content': email_content,
                    'product': target_product,
                    'segment': target_segment,
                    'type': campaign_type,
                    'send_date': send_date,
                    'created_at': datetime.now(),
                    'status': 'Draft'
                }
                st.session_state.email_campaigns.append(new_campaign)
                st.success("✅ Campaign created successfully!")
                st.rerun()
            else:
                st.error("❌ Please fill in all required fields")
        
        # Display Active Campaigns
        st.subheader("📋 Active Campaigns")
        
        if st.session_state.email_campaigns:
            campaigns_df = pd.DataFrame(st.session_state.email_campaigns)
            
            for idx, campaign in enumerate(st.session_state.email_campaigns):
                with st.expander(f"📧 {campaign['name']} - {campaign['status']}"):
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.write(f"**Subject:** {campaign['subject']}")
                        st.write(f"**Product:** {campaign['product']}")
                        st.write(f"**Type:** {campaign['type']}")
                    
                    with col2:
                        st.write(f"**Segment:** {campaign['segment']}")
                        st.write(f"**Send Date:** {campaign['send_date']}")
                        st.write(f"**Status:** {campaign['status']}")
                    
                    with col3:
                        if st.button(f"Send Campaign", key=f"send_{idx}"):
                            st.session_state.email_campaigns[idx]['status'] = 'Sent'
                            st.success("✅ Campaign sent successfully!")
                            st.rerun()
                        
                        if st.button(f"Delete", key=f"delete_{idx}"):
                            st.session_state.email_campaigns.pop(idx)
                            st.success("🗑️ Campaign deleted!")
                            st.rerun()
                    
                    st.write("**Content Preview:**")
                    st.text_area("", value=campaign['content'], height=100, disabled=True, key=f"content_{idx}")
        else:
            st.info("📭 No campaigns created yet. Create your first campaign above!")
        
        # Email Analytics
        st.subheader("📈 Email Campaign Analytics")
        
        if st.session_state.email_campaigns:
            # Generate mock analytics data
            analytics_data = []
            for campaign in st.session_state.email_campaigns:
                if campaign['status'] == 'Sent':
                    analytics_data.append({
                        'Campaign': campaign['name'],
                        'Sent': np.random.randint(1000, 5000),
                        'Opened': np.random.randint(200, 1500),
                        'Clicked': np.random.randint(50, 300),
                        'Converted': np.random.randint(10, 100)
                    })
            
            if analytics_data:
                analytics_df = pd.DataFrame(analytics_data)
                analytics_df['Open Rate'] = (analytics_df['Opened'] / analytics_df['Sent'] * 100).round(2)
                analytics_df['Click Rate'] = (analytics_df['Clicked'] / analytics_df['Opened'] * 100).round(2)
                analytics_df['Conversion Rate'] = (analytics_df['Converted'] / analytics_df['Clicked'] * 100).round(2)
                
                st.dataframe(analytics_df, use_container_width=True)
                
                # Visualizations
                col1, col2 = st.columns(2)
                
                with col1:
                    fig_open_rates = px.bar(
                        analytics_df,
                        x='Campaign',
                        y='Open Rate',
                        title='Email Open Rates by Campaign'
                    )
                    st.plotly_chart(fig_open_rates, use_container_width=True)
                
                with col2:
                    fig_conversion = px.bar(
                        analytics_df,
                        x='Campaign',
                        y='Conversion Rate',
                        title='Conversion Rates by Campaign'
                    )
                    st.plotly_chart(fig_conversion, use_container_width=True)
    
    def render_seo_optimizer(self):
        """Render SEO optimization tools"""
        st.header("🔍 SEO Optimization Dashboard")
        
        # Keyword Analysis
        st.subheader("🎯 Keyword Performance Analysis")
        
        # Display current keyword rankings
        for product, data in st.session_state.seo_keywords.items():
            st.write(f"### {product}")
            
            keyword_df = pd.DataFrame({
                'Keyword': data['keywords'],
                'Current Ranking': data['rankings'],
                'Search Volume': data['search_volume']
            })
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.dataframe(keyword_df, use_container_width=True)
            
            with col2:
                fig_keywords = px.scatter(
                    keyword_df,
                    x='Current Ranking',
                    y='Search Volume',
                    hover_data=['Keyword'],
                    title=f'{product} - Keyword Performance'
                )
                fig_keywords.update_xaxis(autorange="reversed")  # Lower ranking is better
                st.plotly_chart(fig_keywords, use_container_width=True)
        
        # SEO Recommendations
        st.subheader("💡 SEO Recommendations")
        
        recommendations = [
            "📝 Create more content around 'government job preparation' - high search volume, improvable ranking",
            "🔗 Build backlinks for 'employment news paper' to maintain top ranking",
            "📊 Monitor competitor content for 'civil services books' keyword",
            "🎯 Target long-tail keywords like 'employment news weekly subscription'",
            "📱 Optimize mobile page speed - affects search rankings",
            "🏷️ Update meta descriptions for better click-through rates"
        ]
        
        for rec in recommendations:
            st.markdown(f"- {rec}")
        
        # Content Gap Analysis
        st.subheader("📊 Content Gap Analysis")
        
        gap_data = {
            'Topic': ['Job Interview Tips', 'Exam Preparation Strategies', 'Government Schemes', 'Career Guidance'],
            'Search Volume': [12000, 18000, 8500, 15000],
            'Competition': ['Medium', 'High', 'Low', 'Medium'],
            'Opportunity Score': [7.5, 6.2, 8.8, 7.0]
        }
        
        gap_df = pd.DataFrame(gap_data)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.dataframe(gap_df, use_container_width=True)
        
        with col2:
            fig_opportunity = px.bar(
                gap_df,
                x='Topic',
                y='Opportunity Score',
                color='Competition',
                title='Content Opportunity Analysis'
            )
            st.plotly_chart(fig_opportunity, use_container_width=True)
        
        # SEO Tools
        st.subheader("🛠️ SEO Tools")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Keyword Research Tool**")
            new_keyword = st.text_input("Enter keyword to analyze:")
            if st.button("Analyze Keyword"):
                if new_keyword:
                    # Mock analysis
                    volume = np.random.randint(1000, 50000)
                    difficulty = np.random.randint(1, 100)
                    st.write(f"**Search Volume:** {volume:,}")
                    st.write(f"**Difficulty Score:** {difficulty}/100")
                    st.write(f"**Recommendation:** {'High Priority' if difficulty < 50 and volume > 5000 else 'Medium Priority'}")
        
        with col2:
            st.write("**Page Speed Analyzer**")
            url_to_check = st.text_input("Enter URL to check:")
            if st.button("Check Page Speed"):
                if url_to_check:
                    # Mock speed analysis
                    mobile_score = np.random.randint(60, 95)
                    desktop_score = np.random.randint(70, 100)
                    st.write(f"**Mobile Score:** {mobile_score}/100")
                    st.write(f"**Desktop Score:** {desktop_score}/100")
                    st.write(f"**Status:** {'Good' if mobile_score > 80 else 'Needs Improvement'}")
    
    def render_social_media_manager(self):
        """Render social media management interface"""
        st.header("📱 Social Media Marketing Manager")
        
        # Post Scheduler
        st.subheader("📝 Create Social Media Post")
        
        col1, col2 = st.columns(2)
        
        with col1:
            platform = st.selectbox("Platform", ["Facebook", "Twitter", "Instagram", "LinkedIn"])
            post_type = st.selectbox("Post Type", ["Promotional", "Educational", "News Update", "Engagement"])
            schedule_time = st.datetime_input("Schedule Time")
        
        with col2:
            target_product = st.selectbox("Promote Product", ["DPD Journals", "Employment News", "Both"], key="social_product")
            hashtags = st.text_input("Hashtags (comma separated)", placeholder="#government #jobs #preparation")
        
        post_content = st.text_area("Post Content", height=150, placeholder="Write your social media post here...")
        
        if st.button("Schedule Post"):
            if post_content:
                new_post = {
                    'platform': platform,
                    'content': post_content,
                    'hashtags': hashtags,
                    'product': target_product,
                    'type': post_type,
                    'schedule_time': schedule_time,
                    'created_at': datetime.now(),
                    'status': 'Scheduled'
                }
                st.session_state.social_media_posts.append(new_post)
                st.success("✅ Post scheduled successfully!")
                st.rerun()
            else:
                st.error("❌ Please enter post content")
        
        # Scheduled Posts
        st.subheader("📅 Scheduled Posts")
        
        if st.session_state.social_media_posts:
            for idx, post in enumerate(st.session_state.social_media_posts):
                with st.expander(f"{post['platform']} - {post['type']} - {post['status']}"):
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.write(f"**Platform:** {post['platform']}")
                        st.write(f"**Type:** {post['type']}")
                        st.write(f"**Product:** {post['product']}")
                    
                    with col2:
                        st.write(f"**Schedule:** {post['schedule_time']}")
                        st.write(f"**Status:** {post['status']}")
                        st.write(f"**Hashtags:** {post['hashtags']}")
                    
                    with col3:
                        if st.button(f"Post Now", key=f"post_{idx}"):
                            st.session_state.social_media_posts[idx]['status'] = 'Posted'
                            st.success("✅ Post published!")
                            st.rerun()
                        
                        if st.button(f"Delete", key=f"del_post_{idx}"):
                            st.session_state.social_media_posts.pop(idx)
                            st.success("🗑️ Post deleted!")
                            st.rerun()
                    
                    st.text_area("Content:", value=post['content'], height=100, disabled=True, key=f"post_content_{idx}")
        
        # Social Media Analytics
        st.subheader("📊 Social Media Analytics")
        
        # Generate mock social media metrics
        platforms = ['Facebook', 'Twitter', 'Instagram', 'LinkedIn']
        social_metrics = []
        
        for platform in platforms:
            social_metrics.append({
                'Platform': platform,
                'Followers': np.random.randint(1000, 50000),
                'Engagement Rate': np.random.uniform(2, 8),
                'Reach': np.random.randint(5000, 100000),
                'Clicks': np.random.randint(100, 2000),
                'Conversions': np.random.randint(10, 200)
            })
        
        social_df = pd.DataFrame(social_metrics)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.dataframe(social_df, use_container_width=True)
        
        with col2:
            fig_engagement = px.bar(
                social_df,
                x='Platform',
                y='Engagement Rate',
                title='Engagement Rate by Platform (%)'
            )
            st.plotly_chart(fig_engagement, use_container_width=True)
        
        # Content Performance
        col1, col2 = st.columns(2)
        
        with col1:
            fig_reach = px.pie(
                social_df,
                values='Reach',
                names='Platform',
                title='Reach Distribution by Platform'
            )
            st.plotly_chart(fig_reach, use_container_width=True)
        
        with col2:
            fig_conversions = px.scatter(
                social_df,
                x='Clicks',
                y='Conversions',
                color='Platform',
                size='Followers',
                title='Clicks vs Conversions by Platform'
            )
            st.plotly_chart(fig_conversions, use_container_width=True)
    
    def render_analytics_center(self):
        """Render comprehensive analytics center"""
        st.header("📊 Analytics & Insights Center")
        
        # Customer Journey Analysis
        st.subheader("🛤️ Customer Journey Analysis")
        
        journey_data = {
            'Stage': ['Awareness', 'Interest', 'Consideration', 'Purchase', 'Retention'],
            'DPD Journals': [1000, 650, 400, 120, 95],
            'Employment News': [1500, 980, 750, 425, 380]
        }
        
        journey_df = pd.DataFrame(journey_data)
        
        fig_funnel = go.Figure()
        
        for product in ['DPD Journals', 'Employment News']:
            fig_funnel.add_trace(go.Scatter(
                x=journey_df['Stage'],
                y=journey_df[product],
                mode='lines+markers',
                name=product,
                line=dict(width=3),
                marker=dict(size=8)
            ))
        
        fig_funnel.update_layout(
            title='Customer Journey Funnel',
            xaxis_title='Journey Stage',
            yaxis_title='Number of Customers'
        )
        
        st.plotly_chart(fig_funnel, use_container_width=True)
        
        # ROI Analysis
        st.subheader("💰 Return on Investment (ROI) Analysis")
        
        roi_data = {
            'Channel': ['Email Marketing', 'Social Media', 'SEO', 'Amazon Ads', 'Website'],
            'Investment': [15000, 25000, 30000, 40000, 20000],
            'Revenue': [45000, 60000, 120000, 80000, 55000],
            'ROI': [200, 140, 300, 100, 175]
        }
        
        roi_df = pd.DataFrame(roi_data)
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig_roi = px.bar(
                roi_df,
                x='Channel',
                y='ROI',
                title='ROI by Marketing Channel (%)',
                color='ROI',
                color_continuous_scale='Viridis'
            )
            st.plotly_chart(fig_roi, use_container_width=True)
        
        with col2:
            fig_investment = px.scatter(
                roi_df,
                x='Investment',
                y='Revenue',
                color='Channel',
                size='ROI',
                title='Investment vs Revenue by Channel'
            )
            st.plotly_chart(fig_investment, use_container_width=True)
        
        # Detailed Metrics Table
        st.subheader("📋 Detailed Performance Metrics")
        st.dataframe(roi_df, use_container_width=True)
        
        # Predictive Analytics
        st.subheader("🔮 Predictive Analytics")
        
        # Generate future projections
        future_months = ['Jan 2025', 'Feb 2025', 'Mar 2025', 'Apr 2025', 'May 2025', 'Jun 2025']
        
        predictions = {
            'Month': future_months,
            'Predicted Sales': [np.random.randint(8000, 12000) for _ in future_months],
            'Predicted Revenue': [np.random.randint(80000, 150000) for _ in future_months],
            'Confidence': [np.random.uniform(75, 95) for _ in future_months]
        }
        
        pred_df = pd.DataFrame(predictions)
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig_pred_sales = px.line(
                pred_df,
                x='Month',
                y='Predicted Sales',
                title='Sales Forecast (Next 6 Months)',
                markers=True
            )
            st.plotly_chart(fig_pred_sales, use_container_width=True)
        
        with col2:
            fig_pred_revenue = px.line(
                pred_df,
                x='Month',
                y='Predicted Revenue',
                title='Revenue Forecast (Next 6 Months)',
                markers=True
            )
            st.plotly_chart(fig_pred_revenue, use_container_width=True)
        
        # Key Insights
        st.subheader("💡 Key Insights & Recommendations")
        
        insights = [
            "🎯 **SEO is your highest ROI channel** - Consider increasing SEO investment by 20%",
            "📧 **Email marketing shows strong performance** - Expand email list through lead magnets",
            "📱 **Social media engagement is growing** - Focus on Instagram and LinkedIn for better reach",
            "🛒 **Amazon channel needs optimization** - Review product listings and pricing strategy",
            "📈 **Employment News outperforms DPD Journals** - Consider cross-selling strategies",
            "🔄 **Customer retention needs attention** - Implement loyalty programs and follow-up campaigns"
        ]
        
        for insight in insights:
            st.markdown(f"- {insight}")

def main():
    """Main application function"""
    hub = DigitalMarketingHub()
    
    # Sidebar navigation
    st.sidebar.title("🎯 Navigation")
    
    pages = {
        "📊 Dashboard Overview": hub.render_dashboard_overview,
        "📧 Email Marketing": hub.render_email_marketing,
        "🔍 SEO Optimizer": hub.render_seo_optimizer,
        "📱 Social Media": hub.render_social_media_manager,
        "📊 Analytics Center": hub.render_analytics_center
    }
    
    selected_page = st.sidebar.selectbox("Select Page", list(pages.keys()))
    
    # Quick Stats in Sidebar
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 📈 Quick Stats")
    st.sidebar.metric("Today's Sales", f"{np.random.randint(100, 500)}")
    st.sidebar.metric("Active Campaigns", f"{len(st.session_state.email_campaigns)}")
    st.sidebar.metric("Social Posts", f"{len(st.session_state.social_media_posts)}")
    
    # System Status
    st.sidebar.markdown("---")
    st.sidebar.markdown("### ⚙️ System Status")
    st.sidebar.success("✅ Email System: Online")
    st.sidebar.success("✅ Analytics: Online")
    st.sidebar.success("✅ Social Media: Online")
    st.sidebar.info("ℹ️ SEO Tools: Active")
    
    # Help Section
    st.sidebar.markdown("---")  
    st.sidebar.markdown("### 🆘 Help & Support")
    if st.sidebar.button("📖 User Guide"):
        st.sidebar.markdown("""
        **Quick Start Guide:**
        1. Start with Dashboard Overview
        2. Create email campaigns
        3. Monitor SEO performance
        4. Schedule social media posts
        5. Analyze results in Analytics Center
        """)
    
    # Render selected page
    pages[selected_page]()
    
    # Footer
    st.markdown("---")
    st.markdown(
        "<div style='text-align: center; color: #666; font-size: 0.8em;'>"
        "DPD Digital Marketing Hub v1.0 | Built with Streamlit | © 2024"
        "</div>",
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()